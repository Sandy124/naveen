package com.cg.cart.services;

import java.util.List;

import com.cg.cart.beans.Product;
import com.cg.cart.exception.ProductDetailsNotFound;

public interface ProductServices {

	Product acceptProductDetails(Product product) ;

	Product  getProductDetails(int productId) throws ProductDetailsNotFound ;

	List<Product> getAllProductDetails(); 

	boolean removeProductDetails(int productId)throws ProductDetailsNotFound;

	Product  updateProductDetails(int productId,Product product) throws ProductDetailsNotFound;


}
