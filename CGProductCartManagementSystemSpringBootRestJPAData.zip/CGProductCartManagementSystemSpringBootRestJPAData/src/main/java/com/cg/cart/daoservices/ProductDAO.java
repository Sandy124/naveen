package com.cg.cart.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.cart.beans.Product;

public interface ProductDAO   extends JpaRepository<Product, Integer> {

	
	
}
