package com.cg.cart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.cart.beans.Product;
import com.cg.cart.exception.ProductDetailsNotFound;
import com.cg.cart.services.ProductServices;

@Controller
public class ProductServiceController {
          @Autowired
	ProductServices productServices;
	
	
	@RequestMapping(value={"/acceptProductDetails"},method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>acceptProductDetails(@ModelAttribute Product product){
		product=productServices.acceptProductDetails(product);
	return new ResponseEntity<>("Product Details succesfully added Product Id"+product.getProductId(),HttpStatus.OK);

	}	
	@RequestMapping(value={"/removeProductDetails"},method=RequestMethod.DELETE,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>removeProductDetails( @RequestParam   int productId) throws ProductDetailsNotFound{
		productServices.removeProductDetails(productId);
		return new ResponseEntity<>(" Product Details succesfully delete ",HttpStatus.OK);

	}
	@RequestMapping(value={"/getAllProductDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<List<Product>> getAllProductDetailsPathParam(){

	return new  ResponseEntity<List<Product>>(productServices.getAllProductDetails(),HttpStatus.OK);
	}
	@RequestMapping(value= {"/getProductDetails/{productId}"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<Product>getProductDetailsPathParam(@PathVariable(value="productId")int productId) throws ProductDetailsNotFound{
		Product product=productServices.getProductDetails(productId);
		return new ResponseEntity<Product>(product,HttpStatus.OK);	

	}
	
	@RequestMapping(value="/updateProductDetails", method=RequestMethod.PUT, consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>updateProductDetails(@RequestParam  int  productId, Product product) throws ProductDetailsNotFound{
		product=productServices.updateProductDetails(productId, product);
		return new ResponseEntity<>("Product details successfully Updated Product Id:- "+product.getProductId(),HttpStatus.OK);
	}
		
	
}
