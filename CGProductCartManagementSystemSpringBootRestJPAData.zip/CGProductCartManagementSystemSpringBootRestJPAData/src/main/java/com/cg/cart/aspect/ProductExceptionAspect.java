package com.cg.cart.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.cart.exception.ProductDetailsNotFound;
import com.cg.cart.response.CustomResponse;

public class ProductExceptionAspect {

	@ExceptionHandler(ProductDetailsNotFound.class)
	public ResponseEntity<CustomResponse>  ProductDetailsNotFound(Exception e) {
	
	CustomResponse response=new CustomResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value() );
	return new ResponseEntity<CustomResponse>(response,HttpStatus.EXPECTATION_FAILED) ;
}
	}