package com.cg.cart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

//Giving paths for different packages
@SpringBootApplication(scanBasePackages= {"com.cg.cart"})
@EntityScan(basePackages="com.cg.cart.beans")
@EnableJpaRepositories(basePackages="com.cg.cart.daoservices")
@EnableWebMvc
public class CgProductCartManagementSystemSpringBootRestJpaDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgProductCartManagementSystemSpringBootRestJpaDataApplication.class, args);
	}

}
