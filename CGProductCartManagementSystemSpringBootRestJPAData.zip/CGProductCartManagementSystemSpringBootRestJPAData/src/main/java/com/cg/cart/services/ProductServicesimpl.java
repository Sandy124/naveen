package com.cg.cart.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.cart.beans.Product;
import com.cg.cart.daoservices.ProductDAO;
import com.cg.cart.exception.ProductDetailsNotFound;

@Component("productServices")
public class ProductServicesimpl  implements ProductServices {
	@Autowired
	private ProductDAO productDAO;//creating object of ProductDAO

	@Override
	public Product acceptProductDetails(Product product) {

		return productDAO.save(product);//FINDING find particular productId from Table
	}

	@Override
	public Product getProductDetails(int productId) throws ProductDetailsNotFound {

		return	productDAO.findById(productId).orElseThrow(()->  new ProductDetailsNotFound("Deatils Not found"+productId));
	}

	@Override
	public List<Product> getAllProductDetails() {

		return productDAO.findAll();//FIND ALL VALUES OF TABLE
	}

	@Override
	public boolean removeProductDetails(int productId) throws ProductDetailsNotFound {
		productDAO.delete(getProductDetails(productId));//DELETING VALUES FROM TABLE
		return true;
	}

	@Override
	//Used to Update Values from table
 	public Product updateProductDetails(int productId, Product product) throws ProductDetailsNotFound {
	   product.setProductId(product.getProductId());
		product.setName(product.getName());
		product.setModel(product.getModel());
	    product.setPrice(product.getPrice());
		return productDAO.save(product);
	}

}
