package com.cg.pizza.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.Order;
import com.cg.pizza.daoservices.CustomerDao;
import com.cg.pizza.daoservices.OrderDao;
import com.cg.pizza.exception.CustomerDeatilsNotFoundException;
@Component("pizzaServices")
public class PizzaServicesImpl   implements PizzaServices {

	@Autowired
	CustomerDao customerDao;
	@Autowired
	OrderDao orderDao;
		
	Customer customer;
	Order order;
	@Override

	public Customer acceptCustomerDeatails(Customer customer) {

		return customerDao.save(customer);
	}

	@Override
	public Customer getCustomerDetails(int custId) throws CustomerDeatilsNotFoundException {
		customer=customerDao.findById(custId).orElseThrow(()-> new CustomerDeatilsNotFoundException());
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() {

		return customerDao.findAll();
	}

	@Override
	public Customer updateCustomerDetails(int custId, Customer customer) throws CustomerDeatilsNotFoundException {

		Customer customer1=customerDao.findById(custId).orElseThrow(()-> new CustomerDeatilsNotFoundException());
		customer1=customer;
		customerDao.saveAndFlush(customer1);
		return customerDao.saveAndFlush(customer1);
	}

	@Override
	public boolean removeCustomerDetails(int custId) throws CustomerDeatilsNotFoundException {
		customerDao.delete(getCustomerDetails( custId));
		return  true;
	}

	@Override
	public Order acceptOrderDeatails(int custId , Order order) throws CustomerDeatilsNotFoundException {
           customer=getCustomerDetails(custId);
           order.setCustomer(customer);
		return orderDao.save(order);
	}




}
