package com.cg.pizza.aspect;

public class PizzaExceptionAspect {

}
