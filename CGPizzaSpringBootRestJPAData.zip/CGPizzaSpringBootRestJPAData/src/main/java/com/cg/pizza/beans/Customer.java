package com.cg.pizza.beans;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
      
@Entity
public class Customer {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int custId;
	
	
	private String firstName;
	private String lastName;
	private String emailId;
	
	@MapKey
	@OneToMany(mappedBy="customer",fetch=FetchType.EAGER)
		public Map<Integer,Order>orders=new HashMap<Integer,Order>();
		
	public Customer() {	}
		
	
	public Customer(int custId, String firstName, String lastName, String emailId, Map<Integer, Order> orders) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.orders = orders;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Map<Integer, Order> getOrders() {
		return orders;
	}
	public void setOrders(Map<Integer, Order> orders) {
		this.orders = orders;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", emailId="
				+ emailId + ", orders=" + orders + "]";
	}




}
