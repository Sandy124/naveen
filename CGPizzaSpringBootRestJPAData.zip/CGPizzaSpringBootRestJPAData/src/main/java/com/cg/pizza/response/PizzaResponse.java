package com.cg.pizza.response;

public class PizzaResponse {

	
}
