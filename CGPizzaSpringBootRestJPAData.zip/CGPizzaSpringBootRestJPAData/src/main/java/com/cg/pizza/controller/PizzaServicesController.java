package com.cg.pizza.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.Order;
import com.cg.pizza.exception.CustomerDeatilsNotFoundException;
import com.cg.pizza.service.PizzaServices;

@Controller
public class PizzaServicesController {
	
	@Autowired
	PizzaServices pizzaServices;

	@RequestMapping(value="/acceptCustomerDeatails", method=RequestMethod.POST, consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptCustomerDeatails(@ModelAttribute  Customer customer){
		customer=pizzaServices.acceptCustomerDeatails(customer);
		return new ResponseEntity<>("Associate details successfully added associate Id:- "+customer.getCustId(),HttpStatus.OK);
	}

	@RequestMapping(value= {"/getCustomerDetails"},method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<Customer> getCustomerDetails(@PathVariable(value="custId") int custId) throws CustomerDeatilsNotFoundException{
		Customer customer = pizzaServices.getCustomerDetails( custId);
		return new ResponseEntity<Customer>(customer,HttpStatus.OK);
	}

	@RequestMapping(value= {"/getAllAssociateDetails"},  method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<List<Customer>> getAllCustomerDetailPathParam(){
		return new ResponseEntity<List<Customer>>(pizzaServices.getAllCustomerDetails(), HttpStatus.OK);
	}

	@RequestMapping(value="/removeCustomerDetails", method=RequestMethod.DELETE, consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> removeCustomerDetails(@RequestParam int custId) throws CustomerDeatilsNotFoundException{
		pizzaServices.removeCustomerDetails(custId);
		return new ResponseEntity<>("Customer details successfully removed",HttpStatus.OK);
	}

	@RequestMapping(value="/updateCustomerDetails", method=RequestMethod.POST, consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>updateCustomerDetails(@RequestParam  int custId, Customer customer) throws CustomerDeatilsNotFoundException{
		customer=pizzaServices.updateCustomerDetails(custId, customer);
		return new ResponseEntity<>("Customer details successfully Updated customer Id:- "+customer.getCustId(),HttpStatus.OK);
	}

	@RequestMapping(value="/acceptOrderDeatails", method=RequestMethod.POST, consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptOrderDeatails(@ModelAttribute  int custId , Order order) throws CustomerDeatilsNotFoundException{
		order=pizzaServices.acceptOrderDeatails(custId, order);
		return new ResponseEntity<>("Associate details successfully added associate Id:- "+order.getOrderId(),HttpStatus.OK);
	}





















}
