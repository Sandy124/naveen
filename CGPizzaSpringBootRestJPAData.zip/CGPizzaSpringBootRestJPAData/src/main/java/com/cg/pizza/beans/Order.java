package com.cg.pizza.beans;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

         @Entity
public class Order {

	 @Id
	 @GeneratedValue(strategy=GenerationType.AUTO)
	private int orderId;
	 
	private String pizzaName;
	private String quantity;
	
	@JsonIgnore
	@ManyToOne(fetch=FetchType.EAGER)
	Customer customer;
		
	
	public Order() {}
		
	
	public Order(int orderId, String pizzaName, String quantity, Customer customer) {
		super();
		this.orderId = orderId;
		this.pizzaName = pizzaName;
		this.quantity = quantity;
		this.customer = customer;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getPizzaName() {
		return pizzaName;
	}

	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", pizzaName=" + pizzaName + ", quantity=" + quantity + ", customer="
				+ customer + "]";
	}
	
	
	
}
