package com.cg.pizza.exception;

public class CustomerDeatilsNotFoundException  extends Exception{

	public CustomerDeatilsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerDeatilsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CustomerDeatilsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CustomerDeatilsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CustomerDeatilsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
	
}
