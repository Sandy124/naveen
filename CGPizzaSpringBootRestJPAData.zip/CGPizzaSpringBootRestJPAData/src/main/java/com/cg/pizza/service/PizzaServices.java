package com.cg.pizza.service;

import java.util.List;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.Order;
import com.cg.pizza.exception.CustomerDeatilsNotFoundException;

public interface PizzaServices {

	Customer acceptCustomerDeatails(Customer customer);
	Customer getCustomerDetails(int custId) throws CustomerDeatilsNotFoundException;
	List<Customer> getAllCustomerDetails();
	Customer updateCustomerDetails(int custId,Customer customer) throws CustomerDeatilsNotFoundException;
	public boolean removeCustomerDetails(int custId) throws CustomerDeatilsNotFoundException;
	
	Order acceptOrderDeatails( int custId , Order order) throws CustomerDeatilsNotFoundException;
	
}
